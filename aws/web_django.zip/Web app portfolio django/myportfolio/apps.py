from django.apps import AppConfig


class MyportfolioConfig(AppConfig):
    name = 'myportfolio'
