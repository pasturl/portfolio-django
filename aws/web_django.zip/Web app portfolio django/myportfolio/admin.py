from django.contrib import admin
from .models import Experience,Blog,Project,Skill,Connection,Profile,Area,Academic
# Register your models here.


admin.site.register(Experience)
admin.site.register(Blog)
admin.site.register(Project)
admin.site.register(Skill)
admin.site.register(Connection)
admin.site.register(Profile)
admin.site.register(Area)
admin.site.register(Academic)